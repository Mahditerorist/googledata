# google

```python

from gooledata import search

print(search('iran'))